mod api;
mod app;
mod firewall;
mod map;
mod world_data;

fn main() -> eframe::Result<()> {
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([1200.0, 700.0])
            .with_min_inner_size([800.0, 500.0])
            .with_title("CS2 Server Blocker by @ FPSHEAVEN"),
        ..Default::default()
    };

    eframe::run_native(
        "CS2 Server Blocker by @FPSHEAVEN",
        options,
        Box::new(|cc| Ok(Box::new(app::App::new(cc)))),
    )
}
